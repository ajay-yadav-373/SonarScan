import sys, ast, getopt, types 
import subprocess, os
from optparse import OptionParser
from optparse import Option, OptionValueError
#from gxlibrary import constants

def cb(option, opt_str, value, parser):
    args = []
    for arg in parser.rargs:
            if arg[0] != "-":
                    args.append(arg)
            else:
                    del parser.rargs[:len(args)]
                    break
    if getattr(parser.values, option.dest):
            args.extend(getattr(parser.values, option.dest))
    setattr(parser.values, option.dest, args)

def main(argv):
    nodeClientName = ""
    vmName = ''
    nodeList = []
    csName = ""
    registryRoot = os.getenv("CVREG", "/etc/CommVaultRegistry")
    parser = OptionParser()
    parser.add_option("-v", "--virtualmachine", dest = "vm", help = "Commvault instance name")
    parser.add_option("-n", "--node", action = "callback", callback = cb, dest = "node", help = "List of nodes in the GreenPlum setup")
    (options, args) = parser.parse_args()
    vmName =  options.vm
    nodeList =  options.node
    execute = subprocess.Popen(["cat", registryRoot + "/Galaxy/" + vmName + "/CommServe/.properties"], stdout = subprocess.PIPE)
    output = execute.communicate()[0]
    if output.find("sCSCLIENTNAME") != -1:
        pos = output.find("sCSCLIENTNAME")
        csName = output[pos+14:output.find("\n", pos)]

    for node in nodeList:
        execute = subprocess.Popen(["gpssh", "-h " + node, "ls -a " + registryRoot +"/Galaxy/ | cat"], stdout = subprocess.PIPE)
        output = execute.communicate()[0]
        instanceName = ""
        pos = 0
        while output.find("Instance",pos) != -1:
            pos = output.find("Instance",pos)
            instanceName = output[pos : pos + 11]
            execute = subprocess.Popen(["gpssh", "-h " + node, "cat " + registryRoot + "/Galaxy/" + instanceName + "/CommServe/.properties"], stdout = subprocess.PIPE)
            output1 = execute.communicate()[0]
            if output1.find("sCSCLIENTNAME") != -1:
                pos1 = output1.find("sCSCLIENTNAME")
                cs_tmp = output1[pos1+14:output1.find("\n", pos1)]
                if cs_tmp == csName:
                    break
            pos = pos + 1

        execute = subprocess.Popen(["gpssh", "-h " + node, "cat " + registryRoot + "/Galaxy/" + instanceName + "/.properties"], stdout = subprocess.PIPE)
        output = execute.communicate()[0]
        if output.find("sPhysicalNodeName") != -1:
            pos = output.find("sPhysicalNodeName")
            clientName = output[pos+18:output.find("\n", pos)]
            nodeClientName = nodeClientName + node + " " + clientName + "\n"

    print nodeClientName

if  __name__ == '__main__':
    main(sys.argv[1:])

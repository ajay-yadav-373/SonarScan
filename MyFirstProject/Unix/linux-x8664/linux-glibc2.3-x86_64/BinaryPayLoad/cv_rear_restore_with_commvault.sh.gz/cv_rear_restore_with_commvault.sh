#!/bin/sh
flag=0
response="resto.tmp"
GALAXY_BASE=$COMMVAULT_BASE

PATH=$PATH:$GALAXY_BASE; export PATH

REVOKE_FILE="/revoke.xml"
RESTORE_FILE="/restore.xml"

homeDir=`dirname $GALAXY_BASE`
brandingFile="$homeDir/installer/branding"
line=`cat $brandingFile | grep "SSCRIPT="`
phrase=`echo $line | awk '{split($0, a, ";"); print a[1]}'`
script=`echo $phrase | awk '{split($0, a, "="); print a[2]}' | tr -d '"'`
if [ $script == "" ]; then
	script="commvault"
fi

echo "Commvault script to start/stop services: $script"

LogPrint "Restoring user data with CommVault"
echo "Starting CommVault services"
$script restart

echo "Logging into CommServe"
qloginDone=0
retry=3
while [ $retry -gt 0 ];
do

# With ReaR 2.4, stdout and stderr are redirected to ReaR log file. So, the prompts from any command become invisible to the user.
# But the original stdin/stdout/stderr are saved as fd6/fd7/fd8. Hence these redirects.
# https://github.com/rear/rear/wiki/Coding-Style#what-to-do-with-stdin-stdout-and-stderr

	qlogin -cs "$CV_COMMCELL"  -csn "$CV_CLIENTNAME" 0<&6 1>&7 2>&8
	if [ $? -eq 0 ]; then
		qloginDone=1
		break;
	fi
	retry=`expr $retry - 1`
done

CV_RETURNCODE=0
if [ $qloginDone -ne 1 ]; then
	Log "CV Login failed"
	CV_RETURNCODE=1
else
#	Create revoke.xml
	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?>" > $REVOKE_FILE
	echo "<App_RevokeClientCertificateRequest>" >> $REVOKE_FILE
	echo "<client>" >> $REVOKE_FILE
	echo "<GUID></GUID>" >> $REVOKE_FILE
	echo "<clientName>$CV_SOURCE_CLIENT</clientName>" >> $REVOKE_FILE
	echo "</client>" >> $REVOKE_FILE
	echo "</App_RevokeClientCertificateRequest>" >> $REVOKE_FILE

	qoperation execute -af $REVOKE_FILE
	if [ $? -ne 0 ]
	then
		Log "CV: Failed to revoke certificates"
	fi

	$script restart

	Log "Getting user input for restore time"

	pitValue="$( UserInput -I CV_PIT_INPUT -p 'Enter the timestamp in YYYY-MM-DD HH:MM::SS format for UTC timezone. Providing no value proceeds with restoring to the latest.' )"

	addTimeRange=0
	if [[ $pitValue ]]; then
		addTimeRange=1
	fi

	echo "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?>" > $RESTORE_FILE
	echo "<TMMsg_CreateTaskReq>" >> $RESTORE_FILE
	echo "<processinginstructioninfo/>" >> $RESTORE_FILE
	echo "<taskInfo>" >> $RESTORE_FILE
	echo "<task>" >> $RESTORE_FILE
	echo "<taskFlags>" >> $RESTORE_FILE
	echo "<disabled>false</disabled>" >> $RESTORE_FILE
	echo "</taskFlags>" >> $RESTORE_FILE
	echo "<policyType>DATA_PROTECTION</policyType>" >> $RESTORE_FILE
	echo "<taskType>IMMEDIATE</taskType>" >> $RESTORE_FILE
	echo "<initiatedFrom>COMMANDLINE</initiatedFrom>" >> $RESTORE_FILE
	echo "</task>" >> $RESTORE_FILE
	echo "<associations>" >> $RESTORE_FILE
	echo "<subclientName>default</subclientName>" >> $RESTORE_FILE
	echo "<backupsetName>defaultBackupSet</backupsetName>" >> $RESTORE_FILE
	echo "<instanceName>DefaultInstanceName</instanceName>" >> $RESTORE_FILE
	echo "<appName>File System</appName>" >> $RESTORE_FILE
	echo "<clientName>$CV_SOURCE_CLIENT</clientName>" >> $RESTORE_FILE
	echo "</associations>" >> $RESTORE_FILE
	echo "<subTasks>" >> $RESTORE_FILE
	echo "<subTask>" >> $RESTORE_FILE
	echo "<subTaskType>RESTORE</subTaskType>" >> $RESTORE_FILE
	echo "<operationType>RESTORE</operationType>" >> $RESTORE_FILE
	echo "</subTask>" >> $RESTORE_FILE
	echo "<options>" >> $RESTORE_FILE
	echo "<restoreOptions>" >> $RESTORE_FILE
	echo "<browseOption>" >> $RESTORE_FILE
	echo "<commCellId>2</commCellId>" >> $RESTORE_FILE
	echo "<backupset>" >> $RESTORE_FILE
	echo "<backupsetName>defaultBackupSet</backupsetName>" >> $RESTORE_FILE
	echo "<clientName>$CV_SOURCE_CLIENT</clientName>" >> $RESTORE_FILE
	echo "</backupset>" >> $RESTORE_FILE
	if [ $addTimeRange -eq 1 ]; then
		echo "<timeRange>" >> $RESTORE_FILE
		echo "<toTimeValue>$pitValue</toTimeValue>" >> $RESTORE_FILE
		echo "</timeRange>" >> $RESTORE_FILE
	else
		echo "<timeRange/>" >> $RESTORE_FILE
	fi
	echo "<noImage>false</noImage>" >> $RESTORE_FILE
	echo "<useExactIndex>false</useExactIndex>" >> $RESTORE_FILE
	echo "<mediaOption>" >> $RESTORE_FILE
	echo "<library/>" >> $RESTORE_FILE
	echo "<mediaAgent/>" >> $RESTORE_FILE
	echo "<drivePool/>" >> $RESTORE_FILE
	echo "<copyPrecedence>" >> $RESTORE_FILE
	echo "<copyPrecedenceApplicable>false</copyPrecedenceApplicable>" >> $RESTORE_FILE
	echo "</copyPrecedence>" >> $RESTORE_FILE
	echo "<useISCSIMount>false</useISCSIMount>" >> $RESTORE_FILE
	echo "</mediaOption>" >> $RESTORE_FILE
	echo "<timeZone>" >> $RESTORE_FILE
	echo "<TimeZoneName>(UTC) Coordinated Universal Time</TimeZoneName>" >> $RESTORE_FILE
        echo "</timeZone>" >> $RESTORE_FILE
	echo "<listMedia>false</listMedia>" >> $RESTORE_FILE
	echo "</browseOption>" >> $RESTORE_FILE
	echo "<destination>" >> $RESTORE_FILE
	echo "<destPath>/mnt/local</destPath>" >> $RESTORE_FILE
	echo "<destClient>" >> $RESTORE_FILE
	echo "<clientName>$CV_SOURCE_CLIENT</clientName>" >> $RESTORE_FILE
	echo "</destClient>" >> $RESTORE_FILE
	echo "<inPlace>false</inPlace>" >> $RESTORE_FILE
	echo "<isLegalHold>false</isLegalHold>" >> $RESTORE_FILE
	echo "<restoreOnlyIfTargetExists>false</restoreOnlyIfTargetExists>" >> $RESTORE_FILE
	echo "<destinationInstance>" >> $RESTORE_FILE
	echo "<instanceName>DefaultInstanceName</instanceName>" >> $RESTORE_FILE
	echo "<appName>File System</appName>" >> $RESTORE_FILE
	echo "<clientName>$CV_SOURCE_CLIENT</clientName>" >> $RESTORE_FILE
	echo "</destinationInstance>" >> $RESTORE_FILE
	echo "<noOfStreams>1</noOfStreams>" >> $RESTORE_FILE
	echo "</destination>" >> $RESTORE_FILE
	echo "<sharePointRstOption>" >> $RESTORE_FILE
	echo "<is90OrUpgradedClient>false</is90OrUpgradedClient>" >> $RESTORE_FILE
	echo "</sharePointRstOption>" >> $RESTORE_FILE
	echo "<sharePointDocRstOption>" >> $RESTORE_FILE
	echo "<isOnPremiseMigration>false</isOnPremiseMigration>" >> $RESTORE_FILE
	echo "</sharePointDocRstOption>" >> $RESTORE_FILE
	echo "<volumeRstOption>" >> $RESTORE_FILE
	echo "<volumeLeveRestore>false</volumeLeveRestore>" >> $RESTORE_FILE
	echo "</volumeRstOption>" >> $RESTORE_FILE
	echo "<virtualServerRstOption>" >> $RESTORE_FILE
	echo "<isDiskBrowse>false</isDiskBrowse>" >> $RESTORE_FILE
	echo "<viewType>DEFAULT</viewType>" >> $RESTORE_FILE
	echo "<isBlockLevelReplication>false</isBlockLevelReplication>" >> $RESTORE_FILE
	echo "</virtualServerRstOption>" >> $RESTORE_FILE
	echo "<fileOption>" >> $RESTORE_FILE
	echo "<sourceItem>/</sourceItem>" >> $RESTORE_FILE
	echo "<browseFilters>&lt;?xml version='1.0' encoding='UTF-8'?&gt;&lt;databrowse_Query type=\"0\" queryId=\"0\"&gt;&lt;dataParam&gt;&lt;sortParam ascending=\"1\"&gt;&lt;sortBy val=\"38\" /&gt;&lt;sortBy val=\"0\" /&gt;&lt;/sortParam&gt;&lt;paging firstNode=\"0\" pageSize=\"1000\" skipNode=\"0\" /&gt;&lt;/dataParam&gt;&lt;/databrowse_Query&gt;</browseFilters>" >> $RESTORE_FILE
	echo "</fileOption>" >> $RESTORE_FILE
	echo "<impersonation>" >> $RESTORE_FILE
	echo "<useImpersonation>false</useImpersonation>" >> $RESTORE_FILE
	echo "<user>" >> $RESTORE_FILE
	echo "<userName></userName>" >> $RESTORE_FILE
	echo "</user>" >> $RESTORE_FILE
	echo "</impersonation>" >> $RESTORE_FILE
	echo "<commonOptions>" >> $RESTORE_FILE
	echo "<overwriteFiles>true</overwriteFiles>" >> $RESTORE_FILE
	echo "<dataInDeviceNode>false</dataInDeviceNode>" >> $RESTORE_FILE
	echo "<wildCard>false</wildCard>" >> $RESTORE_FILE
	echo "<unconditionalOverwrite>false</unconditionalOverwrite>" >> $RESTORE_FILE
	echo "<stripLevelType>PRESERVE_LEVEL</stripLevelType>" >> $RESTORE_FILE
	echo "<preserveLevel>1</preserveLevel>" >> $RESTORE_FILE
	echo "<stripLevel>2</stripLevel>" >> $RESTORE_FILE
	echo "<restoreACLs>false</restoreACLs>" >> $RESTORE_FILE
	echo "<restoreOnlyStubExists>false</restoreOnlyStubExists>" >> $RESTORE_FILE
	echo "<powerRestore>false</powerRestore>" >> $RESTORE_FILE
	echo "<doNotOverwriteFileOnDisk>false</doNotOverwriteFileOnDisk>" >> $RESTORE_FILE
	echo "<systemStateBackup>false</systemStateBackup>" >> $RESTORE_FILE
	echo "<onePassRestore>false</onePassRestore>" >> $RESTORE_FILE
	echo "<offlineMiningRestore>false</offlineMiningRestore>" >> $RESTORE_FILE
	echo "<clusterDBBackedup>false</clusterDBBackedup>" >> $RESTORE_FILE
	echo "<restoreToDisk>false</restoreToDisk>" >> $RESTORE_FILE
	echo "<syncRestore>false</syncRestore>" >> $RESTORE_FILE
	echo "<restoreToExchange>false</restoreToExchange>" >> $RESTORE_FILE
	echo "<copyToObjectStore>false</copyToObjectStore>" >> $RESTORE_FILE
	echo "</commonOptions>" >> $RESTORE_FILE
	echo "<distributedAppsRestoreOptions>" >> $RESTORE_FILE
	echo "<distributedRestore>false</distributedRestore>" >> $RESTORE_FILE
	echo "<isMultiNodeRestore>false</isMultiNodeRestore>" >> $RESTORE_FILE
	echo "<backupConfiguration/>" >> $RESTORE_FILE
	echo "<clientType>WINDOWS</clientType>" >> $RESTORE_FILE
	echo "</distributedAppsRestoreOptions>" >> $RESTORE_FILE
	echo "</restoreOptions>" >> $RESTORE_FILE
	echo "<adminOpts>" >> $RESTORE_FILE
	echo "<contentIndexingOption>" >> $RESTORE_FILE
	echo "<subClientBasedAnalytics>false</subClientBasedAnalytics>" >> $RESTORE_FILE
	echo "</contentIndexingOption>" >> $RESTORE_FILE
	echo "</adminOpts>" >> $RESTORE_FILE
	echo "</options>" >> $RESTORE_FILE
	echo "<subTaskOperation>OVERWRITE</subTaskOperation>" >> $RESTORE_FILE
	echo "</subTasks>" >> $RESTORE_FILE
	echo "</taskInfo>" >> $RESTORE_FILE
	echo "</TMMsg_CreateTaskReq>" >> $RESTORE_FILE

	echo "Restoring data using CommVault"
	qoperation execute -af $RESTORE_FILE > $response
        if [ $? -ne 0 ]
        then
                Log "CV: Failed to execute restore operation"
                CV_RETURNCODE=2
        else
                jobId=`cat $response | grep "jobIds" | grep -o '".*"' | tr -d '"'`
                if [ "$jobId" ]
                then
                                sleep 120
				echo "Restore job details -"
                                qlist job -j "$jobId" > output
                                cat output | \
                                while read line
                                do
                                        echo $line
                                done
                                echo "Restoring...."

                        while :
                        do
                                sleep 30
                                qlist job -j "$jobId"  > output
                                while read line
                                do
                                	flag=0
					echo $line | grep -E "(Running*|Waiting*|Suspended*|Queued*)"
					if [ $? -eq 0 ]; then
						echo "Job status: $line"
						flag=1
						break;
					fi	
					echo $line | grep "Pending"
					if [ $? -eq 0 ]; then
						echo "Job status: $line. Job went to Pending state."
						flag=2;
						break;
					fi
                                done < output

                                if [[ $flag -eq 0 || $flag -eq 2 ]]; then
                                        break;
                                fi
                        done

                        cat output | \
                        while read line
                        do
                                echo $line | grep -i completed
                                if [ $? -eq 0 ]; then
                                        CV_RETURNCODE=0
                                        qoperation execute -af $REVOKE_FILE
                                        if [ $? -ne 0 ]
                                        then
                                                Log "CV: Failed to revoke certificates"
                                        fi
                                        $script restart
					break;
                                fi
                        done
			if [ $CV_RETURNCODE -ne 0 ]; then
				CV_RETURNCODE=3
				echo "Restore job failed to complete"
			fi
                        rm output
                fi
        fi
	rm $RESTORE_FILE
	rm $REVOKE_FILE
        qlogout
        if [ $? -ne 0 ]
        then
                echo Logout failed.
        fi
        rm $response
fi

CV_ERRORS=(
[0]="Restore job completed successfully"
[1]="Commvault Login failed"
[2]="Commvault failed to execute the restore opertion"
[3]="Commvault restore failed to restore the data"
)

if [ $CV_RETURNCODE -ne 0 ]
then
        reason=$CV_ERRORS[$CV_RETURNCODE]
        Error "The restore did not complete successfully."
fi



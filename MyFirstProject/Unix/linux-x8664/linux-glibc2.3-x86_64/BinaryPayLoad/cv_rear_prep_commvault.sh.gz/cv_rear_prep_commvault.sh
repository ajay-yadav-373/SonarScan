#
# prepare stuff for Galaxy
#

COPY_AS_IS=( "${COPY_AS_IS[@]}" "${COPY_AS_IS_COMMVAULT[@]}" )
COPY_AS_IS_EXCLUDE=( "${COPY_AS_IS_EXCLUDE[@]}" "${COPY_AS_IS_EXCLUDE_COMMVAULT[@]}" )


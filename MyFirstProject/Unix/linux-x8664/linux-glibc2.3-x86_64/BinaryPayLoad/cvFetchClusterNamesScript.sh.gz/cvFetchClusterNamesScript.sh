#!/bin/sh
runCommand(){
	echo $1
	eval $1
}

export HV_PUBKEY=1

fullPathClusterNames="/tmp/clusterNames_$1"

echo "Cluster names are saved in" $fullPathClusterNames
runCommand '/opt/hedvig/bin/hv_deploy --show_all_clusters | grep "Cluster name:" | awk '"'"'{print $3}'"'"' > $fullPathClusterNames'

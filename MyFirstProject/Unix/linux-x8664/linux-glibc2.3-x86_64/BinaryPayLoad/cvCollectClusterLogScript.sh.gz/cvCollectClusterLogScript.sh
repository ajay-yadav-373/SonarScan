#!/bin/sh
runCommand(){
	echo $1
	eval $1
}

collectHedvigLog(){
	#$1 is user name, $2 is src path, $3 is dest path
	fileName=./`echo $2 | awk -F "/home/$1/" '/1/ {print $2}'`
	runCommand "tar rvf $3 -C /home/$1/ $fileName > /dev/null"
	rm -f $fileName
}

export HV_PUBKEY=1

fullPathHedvigLogTar="/home/$2/hedvig_$1.tar"
ansibleLogOutPut="_ansibleLogOutPut_$1"
clusterLogOutPut="_clusterLogOutPut_$1"

echo "### Remove log tar files if they exist"
rm -f $fullPathHedvigLogTar $fullPathHedvigLogTar.gz
if [ ! $? -eq 0 ]; then
	echo "Failed to delete" $fullPathHedvigLogTar $fullPathHedvigLogTar.gz
	exit -1
fi

echo "### Processing cluster" $3

fullNameAnsibleLogOutPut=$3$ansibleLogOutPut
fullPathAnsibleLogOutPut=/tmp/$fullNameAnsibleLogOutPut
echo "### Fetching ansible logs"
runCommand "/opt/hedvig/bin/hv_deploy --fetch_ansible_logs --cluster_name $3 --log_days 3 > $fullPathAnsibleLogOutPut 2>&1"
echo "Command output is saved as" $fullPathAnsibleLogOutPut

fullPathAnsibleLogTargz=`cat $fullPathAnsibleLogOutPut | grep -E -- 'tar.gz' | awk -F  " to " '/1/ {print $2}'`
fullPathAnsibleLogXml=`cat $fullPathAnsibleLogOutPut | grep -E -- '.xml' | awk -F  " to " '/1/ {print $2}'`

if [ -z "$fullPathAnsibleLogTargz" ] || [ ! -f $fullPathAnsibleLogTargz ]; then
	echo "ansible Log Tar.gz doesn't exist"
else
	collectHedvigLog $2 $fullPathAnsibleLogTargz $fullPathHedvigLogTar
fi

if [ -z "$fullPathAnsibleLogXml" ] || [ ! -f $fullPathAnsibleLogXml ]; then
	echo "ansible Log Xml doesn't exist"
else
	collectHedvigLog $2 $fullPathAnsibleLogXml $fullPathHedvigLogTar
fi

cp $fullPathAnsibleLogOutPut /home/$2/
if [ -f /home/$2/$fullNameAnsibleLogOutPut ]; then
	collectHedvigLog $2 /home/$2/$fullNameAnsibleLogOutPut $fullPathHedvigLogTar
fi

fullNameClusterLogOutPut=$3$clusterLogOutPut
fullPathClusterLogOutPut=/tmp/$fullNameClusterLogOutPut
echo "### Fetching cluster logs"
runCommand "/opt/hedvig/bin/hv_deploy --fetch_cluster_logs --cluster_name $3 --log_days 3 > $fullPathClusterLogOutPut 2>&1"
echo "Command output is saved as" $fullPathClusterLogOutPut

fullPathClusterLogTargz=`cat $fullPathClusterLogOutPut | grep -E -- 'tar.gz' | awk -F  " is " '/1/ {print $2}'`
fullPathClusterLogXml=`cat $fullPathClusterLogOutPut | grep -E -- '.xml' | awk -F  " is " '/1/ {print $2}'`

if [ -z "$fullPathClusterLogTargz" ] || [ ! -f $fullPathClusterLogTargz ]; then
	echo "cluster Log Tar.gz doesn't exist"
else
	collectHedvigLog $2 $fullPathClusterLogTargz $fullPathHedvigLogTar
fi

if [ -z "$fullPathClusterLogXml" ] || [ ! -f $fullPathClusterLogXml ]; then
	echo "cluster Log Xml doesn't exist"
else
	collectHedvigLog $2 $fullPathClusterLogXml $fullPathHedvigLogTar
fi

cp $fullPathClusterLogOutPut /home/$2/
if [ -f /home/$2/$fullNameClusterLogOutPut ]; then
	collectHedvigLog $2 /home/$2/$fullNameClusterLogOutPut $fullPathHedvigLogTar
fi

if [ -f $fullPathHedvigLogTar ]; then
	if ! tar tf $fullPathHedvigLogTar &> /dev/null; then
		echo "$fullPathHedvigLogTar isn't a valid tar, please check if disk space is enough"
		rm -f $fullPathHedvigLogTar
		exit -1
	fi

	echo "###" $fullPathHedvigLogTar "is collected"
	exit 0
fi

echo $fullPathHedvigLogTar "### doesn't exist, failed to collect log"
exit -1
